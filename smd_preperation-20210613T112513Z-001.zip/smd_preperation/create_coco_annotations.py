import json
import pandas as pd

coco_json = {'info': {'description': 'singapore maritime',
                      'url': '',
                      'version': '1.0',
                      'year': 2021,
                      'contributor': '',
                      'date_created': '2021/03/17'}
             ,
             'licenses': [{'url': '',
                           'id': 1}]
             ,
             'categories': [{'supercategory': 'water vehicle',
                             'id': 1,
                             'name': 'boat'}]
             ,
             'images': []
             ,
             'annotations': []
             }


def image(row):
    image = {}
    image["height"] = 1080
    image["width"] = 1920
    image["id"] = row.fileid
    image["file_name"] = row.filename
    return image


def annotation(row):
    annotation = {}
    area = (row.xmax - row.xmin) * (row.ymax - row.ymin)
    annotation["segmentation"] = [] # [[row.xmin, row.ymin, row.xmax - row.xmin, row.ymax - row.ymin]]  # [row.xmin, row.ymin, row.width, row.height]
    annotation["iscrowd"] = 0
    annotation["area"] = area
    annotation["image_id"] = row.fileid
    annotation["bbox"] = [row.xmin, row.ymin, row.width, row.height]  # [row.xmin, row.ymin, row.xmax - row.xmin, row.ymax - row.ymin]
    annotation["category_id"] = 1  # row.categoryid
    annotation["id"] = row.annid
    return annotation


def create_json(csv_path, d_type, out_path='/data/mritime/our_dataset/'):
    images = []
    annotations = []

    df = pd.read_csv(csv_path)

    df['fileid'] = df['filename'].astype('category').cat.codes
    df['annid'] = df.index

    # images = df['file_name'].unique()

    for row in df.itertuples():
        annotations.append(annotation(row))

    image_df = df.drop_duplicates(subset=['fileid']).sort_values(by='fileid')
    for row in image_df.itertuples():
        images.append(image(row))

    coco_json["images"] = images
    coco_json["annotations"] = annotations

    json.dump(coco_json, open(f'{out_path}/coco_json_{d_type}.json', "w"), indent=4)


if __name__ == '__main__':
    create_json('/data/mritime/our_dataset/train_labels.csv', 'train')