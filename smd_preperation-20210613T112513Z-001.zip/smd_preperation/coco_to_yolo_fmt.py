import os
from pycocotools.coco import COCO
import requests
import json


# Truncates numbers to N decimals
def truncate(n, decimals=0):
    multiplier = 10 ** decimals
    return int(n * multiplier) / multiplier


def create_yolo_labels(coco_path, d_type, out_path):
    # Download instances_train2017.json from the COCO website and put in the same directory as this script
    coco = COCO(coco_path)
    cats = coco.loadCats(coco.getCatIds())
    nms = [cat['name'] for cat in cats]
    print('COCO categories: \n{}\n'.format(' '.join(nms)))

    # Replace category with whatever is of interest to you
    cat = "boat"
    catIds = coco.getCatIds(catNms=[cat])
    imgIds = coco.getImgIds(catIds=catIds)
    images = coco.loadImgs(imgIds)

    # Create a subfolder in this directory called "downloaded_images". This is where your images will be downloaded into.
    # Comment this entire section out if you don't want to download the images
    # for im in images:
    #     print("im: ", im['file_name'])
    #     img_data = requests.get(im['coco_url']).content
    #     with open('downloaded_images/' + im['file_name'], 'wb') as handler:
    #         handler.write(img_data)

    # Create a subfolder in this directory called "labels". This is where the annotations will be saved in YOLO format

    # j = json.load(open('/data/Maritime/maritime/coco_json.json', 'r'))

    for im in images:
        dw = 1. / im['width']
        dh = 1. / im['height']

        annIds = coco.getAnnIds(imgIds=im['id'], catIds=catIds, iscrowd=None)
        anns = coco.loadAnns(annIds)

        filename = im['file_name'].replace(".jpg", ".txt")
        print(filename)
        os.makedirs(f'{out_path}/labels/{i}/', exist_ok=True)
        with open(f'{out_path}/labels/{d_type}/' + filename, 'a') as myfile:
            for i in range(len(anns)):
                xmin = anns[i]["bbox"][0]
                ymin = anns[i]["bbox"][1]
                xmax = anns[i]["bbox"][2] + anns[i]["bbox"][0]
                ymax = anns[i]["bbox"][3] + anns[i]["bbox"][1]

                x = (xmin + xmax) / 2
                y = (ymin + ymax) / 2

                w = xmax - xmin
                h = ymax - ymin

                x = x * dw
                w = w * dw
                y = y * dh
                h = h * dh

                # Note: This assumes a single-category dataset, and thus the "0" at the beginning of each line.
                mystring = str(
                    "8 " + str(truncate(x, 7)) + " " + str(truncate(y, 7)) + " " + str(truncate(w, 7)) + " " + str(
                        truncate(h, 7)))
                myfile.write(mystring)
                myfile.write("\n")
        myfile.close()

        # with open(f"/data/Maritime/maritime/{d_type}_yolo.txt", "a") as mfile:
            # mfile.write(f'/data/mritime/darknet_yolov4/dataset_smd/train/obj/{im["file_name"]}')
            # mfile.write("\n")
        # mfile.close()

