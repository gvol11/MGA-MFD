import numpy as np
import json
import pandas as pd

# path = '/data2/mritime/smd_tests/test_labels.csv'


def correct_xywh(path, d_type, out_path):
    data = pd.read_csv(path)
    w = 1920
    h = 1080
    for row in data.itertuples():
        i = row.Index

        if row.xmin < 0:
            data.iat[i, 4] = 0
            data.iat[i, 1] = row.xmax

        elif row.xmax > w:
            data.iat[i, 6] = w
            data.iat[i, 1] = w - row.xmin

        if row.ymin < 0:
            data.iat[i, 5] = 0
            data.iat[i, 2] = row.ymax

        elif row.ymax > h:
            data.iat[i, 7] = h
            data.iat[i, 2] = h - row.ymin

    data = data.drop(data[data['class'] > 7].index)
    data['class'] = 3
    data.rename({'class': 'cat'})
    data.to_csv(f'{out_path}\{d_type}_labels_corrected.csv', index=False)