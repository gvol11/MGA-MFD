from create_coco_annotations import create_json
from csv_to_coco_bbox_correction import correct_xywh
from coco_to_yolo_fmt import create_yolo_labels

csv_path = r'D:\dataset\smd'
#csv_path = 'path/to/csv/folder'

output_path = r'D:\dataset\smd'
#output_path = 'path/for/your/data/'

d_type = ['train', 'test']
for i in d_type:
    correct_xywh(fr'{csv_path}\{i}_labels.csv', d_type=i, out_path=output_path)
    create_json(fr'{output_path}\{i}_labels_corrected.csv', d_type=i, out_path=output_path)
    create_yolo_labels(fr'{output_path}\coco_json_{i}.json', d_type=i, out_path=output_path)
