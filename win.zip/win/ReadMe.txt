dataset from - https://sites.google.com/site/dilipprasad/home/singapore-maritime-dataset

https://github.com/tilemmpon/Singapore-Maritime-Dataset-Frames-Ground-Truth-Generation-and-Statistics


1) D:\dataset\smd
2) Singapore_dataset_frames_generation_2nd_dataset.ipynb
3) load_mat_into_csv_xml.py -SMD from URL to csv
4) prepare_smd_data.py 

5) copy to yolo_data

5.1) train_2 to train/images 
5.2) labels\train to train/labels

5.3) test_2 to val/images 
5.4) labels\test to val/labels
